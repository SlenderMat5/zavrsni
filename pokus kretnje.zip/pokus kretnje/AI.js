
class Pijun{
	constructor(num){
	this.poz = num;
	}
	
	static pos(x,y){

	window.alert(/*this.poz*/ 2);
		
	}
	static move(x,y){
		
	}
	
}